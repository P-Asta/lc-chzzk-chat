# Fixed Item Rotation

Fixes the angle to make it easier to organize items on the ship.
