# ChzzkChat

치지직에 채팅/후원을 리썰채팅으로 가저옵니다

`ChzzkChat.cfg`에 channelid를 넣어주세요!
만약 `ChzzkChat.cfg`가 없다면 설치후 실행을 한번 해주면 나올꺼에요 XD
![alt text](https://github.com/P-Asta/lc-chzzk-chat/raw/main/thunderstore/image-1.png)
